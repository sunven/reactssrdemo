export default {
	secret: 'dsafsdfasdfasd'
}